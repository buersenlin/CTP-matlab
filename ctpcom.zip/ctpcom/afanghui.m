
function a=afanghui(str)
a=str2func(str)

%���ܷ����ʺ���Ϣ��Ȩ�������ѱ�֤��ȣ�
function funOnAcc(varargin)
disp('account information received');
global accountinformation;
PreBalance=varargin{3};
Balance =varargin{4};
Available =varargin{5};
Commission =varargin{6};
FrozenCommission =varargin{7};
Margin =varargin{8};
FrozenMargin =varargin{9};
CloseProfit =varargin{10};
PositionProfit =num2cell(varargin{11});

accountinformation(2,1:9)=[PreBalance,Balance,Available,Commission ,FrozenCommission,Margin ,FrozenMargin,CloseProfit,PositionProfit];

%���ܷ��سֲ���Ϣ��ӯ���ֲֵȣ� 
function funOnPosition(varargin)
disp('account position received');
global positioninfo
InstrumentID=varargin{3};
IsLong =varargin{4};
Volume =varargin{5};
CloseProfit =varargin{6};
PositionProfit =varargin{7};
AvgPositionPrice =varargin{8};
AvgOpenPrice =varargin{9};
TotalClosable =varargin{10};
TodayClosable=num2cell(varargin{11});

positioninfo(2,1:9)=[InstrumentID,IsLong,Volume,CloseProfit,PositionProfit ,AvgPositionPrice,AvgOpenPrice ,TotalClosable,TodayClosable ];

%��������TICK
function funOnMarketData(varargin)
disp('maket data received');
global instrumentid tick countrow  tick2  countrow2
InstrumentID=varargin{3};
time=varargin{18}; 
UpdateTime=varargin{19};
LastPrice=varargin{11};
Volume=varargin{13};
AskPrice1=varargin{6};
AskVolume1=varargin{7};
BidPrice1=varargin{4};
BidVolume1=num2cell(varargin{5});
%strcmp�Ƚ��ַ���,�������ֵ��ID�͵�1�е�һ��ͬ�����򱣴浽tick
if strcmp(InstrumentID,char(instrumentid(1,1)))
countrow=countrow+1;
tick(countrow,1:9)=[InstrumentID,time ,UpdateTime,LastPrice,Volume ,AskPrice1,AskVolume1,BidPrice1,BidVolume1];
end
%strcmp�Ƚ��ַ���,�������ֵ��ID�͵�2�е�һ��ͬ�����򱣴浽tick
if strcmp(InstrumentID,char(instrumentid(1,2)))
countrow2=countrow2+1;
tick2(countrow2,1:9)=[InstrumentID,time ,UpdateTime,LastPrice,Volume ,AskPrice1,AskVolume1,BidPrice1,BidVolume1];
end














